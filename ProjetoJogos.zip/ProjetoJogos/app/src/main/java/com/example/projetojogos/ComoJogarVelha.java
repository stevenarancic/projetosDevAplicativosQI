package com.example.projetojogos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ComoJogarVelha extends AppCompatActivity {
    Button btnJogar1, btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_como_jogar_velha);

        btnJogar1 = findViewById(R.id.btnJogar1);
        btnVoltar = findViewById(R.id.btnVoltar);

        btnJogar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                comoJogar();
            }
        });

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                janelaVoltar();
            }
        });
    }

    private void comoJogar() {
        Intent janelaJogar = new Intent(this, ComoJogarVelha.class);
        startActivity(janelaJogar);
    }

    private void janelaVoltar() {
        Intent janelaHome = new Intent(this, VelhaMain.class);
        startActivity(janelaHome);
    }
}