package com.example.projetojogos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnPuzzle, btnJogoVelha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPuzzle = findViewById(R.id.buttonJogoVelha);
        btnJogoVelha = findViewById(R.id.buttonPuzzle);

        btnPuzzle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirPuzzle();
            }
        });

        btnJogoVelha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirJogoVelha();
            }
        });
    }

    private void abrirPuzzle() {
        Intent abrirJanelaPuzzle = new Intent(this, PuzzleMain.class);
        startActivity(abrirJanelaPuzzle);
    }

    private void abrirJogoVelha() {
        Intent abrirJanelaVelha = new Intent(this, VelhaMain.class);
        startActivity(abrirJanelaVelha);
    }
}